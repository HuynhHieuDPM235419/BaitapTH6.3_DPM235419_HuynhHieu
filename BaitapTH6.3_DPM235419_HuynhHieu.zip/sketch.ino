#include <WiFi.h>
#include <WiFiClient.h>

// 1. Cấu hình mạng WiFi kế thừa chuẩn từ Bài 6.2
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL 6 // Cố định kênh 6 giúp kết nối tức thì trên Wokwi

// 2. Thông số máy chủ đám mây dweet.io
const char* host = "dweet.io";
const int httpPort = 80;

// Tên định danh thiết bị trên dweet.io (bạn có thể đổi tên nếu muốn)
const String thingName = "esp32-wokwi-demo-63";

void setup() {
  Serial.begin(115200);
  delay(10);

  Serial.println();
  Serial.print("Connecting to WiFi ");
  Serial.println(WIFI_SSID);

  // Kết nối WiFi với kênh 6 tương tự bài 6.2
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL);

  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }

  Serial.println(" Connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  // Trì hoãn 5 giây giữa các lần gửi dữ liệu lên đám mây
  delay(5000);

  Serial.print("\nDang ket noi den host: ");
  Serial.println(host);

  // Tạo đối tượng WiFiClient để thiết lập kết nối TCP
  WiFiClient client;
  if (!client.connect(host, httpPort)) {
    Serial.println("Ket noi that bai!");
    return;
  }

  // Tạo gói tin dữ liệu gửi lên dweet.io (ví dụ gửi trạng thái và số ngẫu nhiên)
  int sampleValue = random(20, 35); // Giả lập giá trị nhiệt độ
  String url = "/dweet/for/" + thingName + "?status=running&temp=" + String(sampleValue);

  Serial.print("Dang yeu cau URL: ");
  Serial.println(url);

  // Gửi HTTP GET Request tới server
  client.print(String("GET ") + url + " HTTP/1.1\r\n" +
               "Host: " + host + "\r\n" +
               "Connection: close\r\n\r\n");

  // Đợi phản hồi từ server (timeout 5 giây)
  unsigned long timeout = millis();
  while (client.available() == 0) {
    if (millis() - timeout > 5000) {
      Serial.println(">>> Het thoi gian cho phan hoi!");
      client.stop();
      return;
    }
  }

  // Đọc dữ liệu JSON trả về từ dweet.io và hiển thị lên Serial Monitor
  Serial.println("Phan hoi tu server:");
  while (client.available()) {
    String line = client.readStringUntil('\r');
    Serial.print(line);
  }

  Serial.println("\nDang dong ket noi");
}